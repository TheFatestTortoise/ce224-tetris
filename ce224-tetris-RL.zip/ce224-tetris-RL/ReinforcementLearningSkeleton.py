# -*- coding: utf-8 -*-
"""
Created on Mon Apr 24 16:40:26 2023

@author: Mason
"""
import random
import consts
import math
global bestSetMean

bestSetMean = 0

def recalculateWeights(currentSetMean, loopCount):
    global bestSetMean
    
    
    if currentSetMean > bestSetMean:
        bestSetMean = currentSetMean

        consts.previousWEIGHTS = [consts.HEIGHT_WEIGHT, consts.HOLES_WEIGHT, consts.FLAT_WEIGHT, consts.WELL_WEIGHT, consts.badWELL_WEIGHT]
        

        consts.HEIGHT_WEIGHT  += consts.HEIGHT_WEIGHT * random.uniform(-0.5, 0.5) * math.exp(-loopCount//3)
        consts.HOLES_WEIGHT   += consts.HOLES_WEIGHT * random.uniform(-0.5, 0.5) * math.exp(-loopCount//3)
        consts.FLAT_WEIGHT    += consts.FLAT_WEIGHT * random.uniform(-0.5, 0.5) * math.exp(-loopCount//3)
        consts.WELL_WEIGHT    += consts.WELL_WEIGHT * random.uniform(-0.5, 0.5) * math.exp(-loopCount//3)
        consts.badWELL_WEIGHT += consts.badWELL_WEIGHT * random.uniform(-0.5, 0.5) * math.exp(-loopCount//3)
        
        consts.currentWEIGHTS = [consts.HEIGHT_WEIGHT, consts.HOLES_WEIGHT, consts.FLAT_WEIGHT, consts.WELL_WEIGHT, consts.badWELL_WEIGHT]
    else:
        
        consts.HEIGHT_WEIGHT  = consts.previousWEIGHTS[0] + (consts.previousWEIGHTS[0] * random.uniform(-0.5, 0.5) * math.exp(-loopCount//3))
        consts.HOLES_WEIGHT   = consts.previousWEIGHTS[1] + (consts.previousWEIGHTS[1] * random.uniform(-0.5, 0.5) * math.exp(-loopCount//3))
        consts.FLAT_WEIGHT    = consts.previousWEIGHTS[2] + (consts.previousWEIGHTS[2] * random.uniform(-0.5, 0.5) * math.exp(-loopCount//3))
        consts.WELL_WEIGHT    = consts.previousWEIGHTS[3] + (consts.previousWEIGHTS[3] * random.uniform(-0.5, 0.5) * math.exp(-loopCount//3))
        consts.badWELL_WEIGHT = consts.previousWEIGHTS[4] + (consts.previousWEIGHTS[4] * random.uniform(-0.5, 0.5) * math.exp(-loopCount//3))
        
        consts.currentWEIGHTS = [consts.HEIGHT_WEIGHT, consts.HOLES_WEIGHT, consts.FLAT_WEIGHT, consts.WELL_WEIGHT, consts.badWELL_WEIGHT]
    '''
    HEIGHT_WEIGHT = 20
    HOLES_WEIGHT = 50
    FLAT_WEIGHT = 10
    WELL_WEIGHT = 1/4
    badWELL_WEIGHT = 1
    '''
    
    
    