import consts
from state import State

import threading

import ReinforcementLearningSkeleton as RLS
## you will need to do python -m pip install windows-curses
# to get this to work on the windows computers (then run from command line)

global movesFromThreads
global use_ai

movesFromThreads = []
use_ai = True # to use ai, do: python main.py ai
'''
def get_input(screen):
    while True:
        # wait for user input
        char = screen.getch()

        if char == ord('a'):
            # rotate left
            return consts.ROT_COUNTER
        elif char == ord('f'):
            # rotate right
            return consts.ROT_CLOCK
        elif char == curses.KEY_DOWN:
            # move down
            return consts.DOWN
        elif char == curses.KEY_LEFT:
            # move left
            return consts.LEFT
        elif char == curses.KEY_RIGHT:
            # move right
            return consts.RIGHT
'''

def main():
    global use_ai
    global movesFromThreads
    #screen = curses.initscr()
    #curses.noecho()
    #curses.curs_set(0)
    #screen.keypad(True)

    currentState = State()
    currentState.start_game()

    moves = 0

    while True:
        #currentState.display(screen)
        if currentState.lost: break

        if use_ai:
            currentState.lowestNumHoles = 1000
            action,score=currentState.search()
            #screen.refresh()

        prev_state = currentState.active
        currentState.move(action)
        if action==consts.DOWN and currentState.active==prev_state:
            currentState.place()
            currentState.activate_next_piece()
            moves += 1
    movesFromThreads.append(moves)
iterations = 0
runningSum = 0
while True:
    
    iterations += consts.THREAD_COUNT
    print("Starting loop", iterations/consts.THREAD_COUNT)
    print("Current Weights", consts.currentWEIGHTS)
    
    moves1 = threading.Thread(target = main, args = ())
    moves2 = threading.Thread(target = main, args = ())
    moves3 = threading.Thread(target = main, args = ())
    moves4 = threading.Thread(target = main, args = ())
    moves5 = threading.Thread(target = main, args = ())
    moves6 = threading.Thread(target = main, args = ())
    moves7 = threading.Thread(target = main, args = ())
    moves8 = threading.Thread(target = main, args = ())
    moves9 = threading.Thread(target = main, args = ())
    moves10 = threading.Thread(target = main, args = ())

    
    moves1.start()
    moves2.start()
    moves3.start()
    moves4.start()
    moves5.start()
    moves6.start()
    moves7.start()
    moves8.start()
    moves9.start()
    moves10.start()

    
    moves1.join()
    moves2.join()
    moves3.join()
    moves4.join()
    moves5.join()
    moves6.join()
    moves7.join()
    moves8.join()
    moves9.join()
    moves10.join()
    
    mean = sum(movesFromThreads)/len(movesFromThreads)
    print("There were", movesFromThreads)
    print("The set mean was", mean)
    
    RLS.recalculateWeights(mean, iterations/consts.THREAD_COUNT)
    
    movesFromThreads.clear()
    