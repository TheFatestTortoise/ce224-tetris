import state

state = state.State()
state.occupied = [[False,False,False,False],
                  [False,False,False,False],
                  [False,True,False,False],
                  [False,False,False,False]]
state.eval()
